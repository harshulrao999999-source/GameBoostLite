# GameBoost Lite

Honest game booster for low-end Android (built for Oppo A3s, Android 8.1, 2 GB RAM).
Kotlin, MVVM, coroutines. No internet permission, no ads, no analytics, no third-party SDKs.
UI is built in code (no XML layouts, no Compose) to keep the APK and RAM small.

## File tree
```
GameBoostLite/
├─ settings.gradle.kts, build.gradle.kts, gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties
├─ .github/workflows/build.yml          (optional: build the APK online, no PC needed)
└─ app/
   ├─ build.gradle.kts, proguard-rules.pro
   └─ src/main/
      ├─ AndroidManifest.xml
      ├─ java/com/gameboost/lite/
      │   ├─ MainActivity.kt      single activity, all screens, permission explainers
      │   ├─ MainViewModel.kt     state + loading (MVVM)
      │   ├─ Core.kt              Prefs, RAM/storage, Usage Access check, foreground tracker
      │   ├─ Apps.kt              app lists, whitelist, recent apps, cache sizes, auto-start
      │   ├─ Booster.kt           Boost + GameMode (DND / brightness, restored safely)
      │   ├─ GameService.kt       foreground service: game watcher, overlay, auto-boost
      │   ├─ DeepCleanService.kt  opt-in accessibility "Force stop" helper
      │   └─ Ui.kt                tiny view helpers
      └─ res/ values/strings.xml, values/themes.xml, xml/accessibility_config.xml, drawable/ic_*.xml
```

## Build the APK
**Option A: Android Studio (PC)**
1. Install Android Studio Hedgehog (2023.1.1) or newer. Open the `GameBoostLite` folder, accept the Gradle sync and SDK 33 download.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). For the small optimized one: View > Tool Windows > Build Variants > `release`, then build.
3. APK: `app/build/outputs/apk/release/app-release.apk` (release is signed with the debug key, fine for personal use).

**Option B: no PC.** Put the folder in a free GitHub repo. Actions > "Build APK" > Run workflow. Download the `GameBoostLite-apk` artifact.

## Install on the phone
Copy the APK to the phone, open it, allow "Install unknown apps" for your file manager/browser when asked, tap Install.
Or with USB debugging on: `adb install -r app-release.apk`.

## First run
Nothing is requested at launch. Each permission is explained right before it is needed: Usage Access (game detection, recent apps, cache sizes), Do Not Disturb, Modify system settings (brightness), Draw over apps (overlay), Accessibility (Deep Clean only).
Oppo tip: also lock GameBoost in Recent Apps and allow its auto-start, otherwise ColorOS may kill the watcher service.

## Decisions
- targetSdk 27 as requested, so no foreground-service-type or background-location rules apply. Android 14+ still installs targetSdk 27 apps.
- Boost only touches non-system apps (FLAG_SYSTEM unset) that are not whitelisted. Launcher, keyboard, dialer, SMS app and this app are auto-protected.
- Boost result = measured `availMem` before and after. If nothing was freed it says so.
- Game Mode saves your DND/brightness before changing them and stores them on disk, so even if the service is killed they are restored at the next start.
- Leaving a game for ~8 seconds ends Game Mode (so answering a quick message won't).
- StorageStatsManager is available from API 26 (your minSdk), so cache sizes are real when Usage Access is granted; otherwise they are hidden.

## Limitations (what Android does not allow)
- No app can clear other apps' cache silently (only deep-link to the app's page), or read other apps' RAM use on 8.1, so no per-app MB figures.
- `killBackgroundProcesses` only stops background processes; apps with services/alarms restart, and foreground or system apps are untouchable. Gains can be small or temporary.
- Force stop is only possible through the Accessibility trick or by hand. Button labels are matched in English/Chinese; other firmware languages may need extra strings.
- Oppo auto-start screen class names vary by ColorOS version; if none match, the app falls back to battery settings. Apps can't toggle auto-start themselves.
- Developer options values (animation scales, process limit) can't be written by apps; the guide only deep-links.
- Special permissions (Usage, Overlay, DND, Write settings, Accessibility) can only be granted by you in system screens.
- ColorOS may kill background services regardless of what apps do.
- Not compiled or run on a device when this was written. Expect to fix small compile or UI issues on first sync. RAM (<40 MB) and APK size (<8 MB) are design targets, so measure them.
- Language setting works, but only English strings ship. Add `res/values-es/strings.xml` etc. to translate.

## 5 ideas for v2
1. Per-game profiles (own brightness, overlay, DND, auto-stop list).
2. Session log with a small chart of free RAM and temperature during play.
3. Overlay extras: battery temperature and a "boost now" tap target.
4. Home-screen shortcut and Quick Settings tile for one-tap boost.
5. Scheduled low-priority cleanup (e.g. nightly) plus a "last boosted" widget, using WorkManager only if it stays under the size budget.
