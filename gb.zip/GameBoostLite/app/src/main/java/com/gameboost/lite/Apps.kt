package com.gameboost.lite

import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

data class AppItem(val pkg: String, val label: String)

object Apps {
    fun isSystem(ai: ApplicationInfo) = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0

    /** Apps that have a launcher icon (excluding this app). */
    fun launchable(c: Context): List<AppItem> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != c.packageName }
            .map { AppItem(it.first, it.second) }
            .sortedBy { it.label.lowercase() }
    }

    /** Packages that are never killed: us, launcher, keyboard, dialer, SMS app, plus the user's whitelist. */
    fun protectedPkgs(c: Context): Set<String> {
        val s = HashSet<String>()
        s.add(c.packageName)
        try {
            c.packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {
        }
        try {
            Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { s.add(it) }
        } catch (e: Exception) {
        }
        try {
            (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s.add(it) }
        } catch (e: Exception) {
        }
        try {
            Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) }
        } catch (e: Exception) {
        }
        s.addAll(Prefs.set(c, Prefs.WHITE))
        return s
    }

    /** Launchable apps used in the last 3 hours, newest first, with last-used time. */
    fun recent(c: Context): List<Pair<AppItem, Long>> {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val stats = try {
            um.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 86_400_000L, now) ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }
        val known = launchable(c).associateBy { it.pkg }
        return stats.filter { it.lastTimeUsed > now - 3 * 3_600_000L && it.packageName in known }
            .sortedByDescending { it.lastTimeUsed }
            .distinctBy { it.packageName }
            .map { known[it.packageName]!! to it.lastTimeUsed }
    }

    /** Cache size in bytes, or -1 if unavailable. Needs Usage Access. */
    fun cacheSize(c: Context, pkg: String): Long = try {
        val ssm = c.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, Process.myUserHandle()).cacheBytes
    } catch (e: Exception) {
        -1L
    }

    /** Clears this app's own cache directories; returns bytes freed. */
    fun clearOwnCache(c: Context): Long {
        var n = 0L
        for (d in listOfNotNull(c.cacheDir, c.externalCacheDir)) {
            d.listFiles()?.forEach { f ->
                n += f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                f.deleteRecursively()
            }
        }
        return n
    }
}

object AutoStart {
    /** Non-system apps that declare a BOOT_COMPLETED receiver. */
    fun list(c: Context): List<AppItem> {
        val pm = c.packageManager
        return pm.queryBroadcastReceivers(Intent(Intent.ACTION_BOOT_COMPLETED), 0)
            .map { it.activityInfo.applicationInfo }
            .filter { !Apps.isSystem(it) }
            .distinctBy { it.packageName }
            .map { AppItem(it.packageName, it.loadLabel(pm).toString()) }
            .sortedBy { it.label.lowercase() }
    }

    /** Tries known ColorOS/Oppo auto-start screens. Returns false if none exist on this firmware. */
    fun openManager(c: Context): Boolean {
        val targets = listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity"
        )
        for ((p, a) in targets) {
            try {
                c.startActivity(Intent().setComponent(ComponentName(p, a)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) {
            }
        }
        return false
    }
}
