package com.gameboost.lite

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class BoostResult(val before: Long, val after: Long, val asked: Int)

object Booster {
    /** Asks Android to stop background processes of non-system, non-protected apps. Measures real free RAM. */
    suspend fun boost(c: Context, keep: Set<String> = emptySet()): BoostResult = withContext(Dispatchers.Default) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = SysInfo.mem(c).avail
        val skip = Apps.protectedPkgs(c) + keep
        var n = 0
        for (ai in c.packageManager.getInstalledApplications(0)) {
            if (Apps.isSystem(ai) || ai.packageName in skip) continue
            try {
                am.killBackgroundProcesses(ai.packageName)
                n++
            } catch (e: SecurityException) {
            }
        }
        delay(1200) // let the kernel actually reclaim memory before measuring
        BoostResult(before, SysInfo.mem(c).avail, n)
    }
}

/** DND + brightness while a game runs. Previous values are persisted so a crash can't leave them changed. */
object GameMode {
    fun apply(c: Context) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Prefs.bool(c, "dnd", true) && nm.isNotificationPolicyAccessGranted) {
                if (Prefs.int(c, "sv_f", -1) == -1) Prefs.putInt(c, "sv_f", nm.currentInterruptionFilter)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        } catch (e: Exception) {
        }
        try {
            if (Prefs.bool(c, "bright", false) && Settings.System.canWrite(c)) {
                val r = c.contentResolver
                if (Prefs.int(c, "sv_m", -1) == -1) {
                    Prefs.putInt(c, "sv_m", Settings.System.getInt(r, Settings.System.SCREEN_BRIGHTNESS_MODE))
                    Prefs.putInt(c, "sv_b", Settings.System.getInt(r, Settings.System.SCREEN_BRIGHTNESS))
                }
                Settings.System.putInt(
                    r, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(
                    r, Settings.System.SCREEN_BRIGHTNESS, (Prefs.int(c, "level", 50) * 255 / 100).coerceIn(1, 255)
                )
            }
        } catch (e: Exception) {
        }
    }

    fun restore(c: Context) {
        val f = Prefs.int(c, "sv_f", -1)
        val b = Prefs.int(c, "sv_b", -1)
        val m = Prefs.int(c, "sv_m", -1)
        try {
            if (f != -1) c.getSystemService(NotificationManager::class.java).setInterruptionFilter(f)
        } catch (e: Exception) {
        }
        try {
            if (m != -1 && Settings.System.canWrite(c)) {
                val r = c.contentResolver
                if (b != -1) Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS, b)
                Settings.System.putInt(r, Settings.System.SCREEN_BRIGHTNESS_MODE, m)
            }
        } catch (e: Exception) {
        }
        Prefs.putInt(c, "sv_f", -1)
        Prefs.putInt(c, "sv_b", -1)
        Prefs.putInt(c, "sv_m", -1)
    }
}
