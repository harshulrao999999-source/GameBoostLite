package com.gameboost.lite

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Environment
import android.os.Process
import android.os.StatFs

object Prefs {
    const val GAMES = "games"
    const val WHITE = "white"
    const val DEEP = "deep"

    private fun sp(c: Context) =
        (c.applicationContext ?: c).getSharedPreferences("gb", Context.MODE_PRIVATE)

    fun set(c: Context, k: String): MutableSet<String> = HashSet(sp(c).getStringSet(k, emptySet())!!)
    fun toggle(c: Context, k: String, p: String): Boolean {
        val s = set(c, k)
        val added = s.add(p)
        if (!added) s.remove(p)
        sp(c).edit().putStringSet(k, s).apply()
        return added
    }
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

data class Mem(val total: Long, val avail: Long) {
    val used get() = total - avail
}

object SysInfo {
    fun mem(c: Context): Mem {
        val m = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m)
        return Mem(m.totalMem, m.availMem)
    }

    /** Returns (total, free) bytes of internal storage. */
    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return s.totalBytes to s.availableBytes
    }

    fun mb(b: Long) = b / 1048576
}

object Usage {
    fun has(c: Context): Boolean = try {
        val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) ==
            AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }
}

/** Tracks the foreground app from UsageEvents. Cheap: only reads events since the last poll. */
class FgTracker(c: Context) {
    private val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var last = System.currentTimeMillis() - 60_000
    private var current: String? = null

    fun poll(): String? {
        val now = System.currentTimeMillis()
        try {
            val ev = um.queryEvents(last, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) current = e.packageName
                else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && current == e.packageName) current = null
            }
        } catch (x: SecurityException) {
        }
        last = now - 1000
        return current
    }
}
