package com.gameboost.lite

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Opt-in. Opens each chosen app's "App info" page in system Settings and taps "Force stop" + "OK".
 * It only listens to com.android.settings (see res/xml/accessibility_config.xml) and never reads other apps.
 */
class DeepCleanService : AccessibilityService() {
    companion object {
        @Volatile var instance: DeepCleanService? = null
        fun enabled() = instance != null
        fun run(pkgs: List<String>): Boolean {
            val s = instance ?: return false
            s.h.post { s.begin(pkgs) }
            return true
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var step = 0 // 0 idle, 1 wait for Force stop, 2 wait for confirm, 3 moving on

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    private fun begin(p: List<String>) {
        queue.clear()
        queue.addAll(p)
        next()
    }

    private fun next() {
        h.removeCallbacksAndMessages(null)
        val p = queue.removeFirstOrNull()
        if (p == null) {
            step = 0
            performGlobalAction(GLOBAL_ACTION_HOME)
            return
        }
        step = 1
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        h.postDelayed({ next() }, 6000) // timeout: skip this app if the button never shows up
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (step != 1 && step != 2) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != "com.android.settings") return
        if (step == 1) {
            val n = find(root, listOf("Force stop", "FORCE STOP", "强行停止", "强制停止")) ?: return
            if (n.isEnabled) {
                n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                step = 2
            } else { // app isn't running, nothing to stop
                step = 3
                h.postDelayed({ next() }, 300)
            }
        } else {
            val n = find(root, listOf("OK", "确定", "确认")) ?: return
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            step = 3
            h.postDelayed({ next() }, 900)
        }
    }

    private fun find(root: AccessibilityNodeInfo, texts: List<String>): AccessibilityNodeInfo? {
        for (t in texts) for (n in root.findAccessibilityNodeInfosByText(t)) {
            if (!n.text?.toString().equals(t, true)) continue
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null) return x
        }
        return null
    }
}
