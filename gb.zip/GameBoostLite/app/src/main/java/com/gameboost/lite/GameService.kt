package com.gameboost.lite

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * One lightweight foreground service:
 *  - while a game is active: polls the foreground app every 2 s, shows the overlay, restores settings when you leave
 *  - if "auto-boost" is on: also watches for your selected games and boosts when one opens
 * It stops itself as soon as there is nothing to do.
 */
class GameService : Service() {
    companion object {
        fun start(c: Context, game: String?) {
            val i = Intent(c, GameService::class.java)
            if (game != null) i.putExtra("game", game)
            c.startForegroundService(i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    @Volatile private var game: String? = null
    @Volatile private var off = 0
    private var overlay: TextView? = null
    private lateinit var tracker: FgTracker

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tracker = FgTracker(this)
        GameMode.restore(this) // clean up if a previous run was killed mid-game
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("gb", "GameBoost", NotificationManager.IMPORTANCE_MIN))
        startForeground(
            1,
            Notification.Builder(this, "gb").setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(getString(R.string.notif)).build()
        )
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        i?.getStringExtra("game")?.let { g ->
            game = g
            off = -5 // grace period while the game is still loading
            scope.launch {
                GameMode.apply(this@GameService)
                showOverlay()
            }
        }
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        while (true) {
            delay(2000)
            val fg = tracker.poll()
            val g = game
            if (g == null) {
                if (!Prefs.bool(this, "auto", false)) {
                    stopSelf()
                    return
                }
                if (fg != null && fg in Prefs.set(this, Prefs.GAMES)) {
                    game = fg
                    off = -3
                    Booster.boost(this, setOf(fg))
                    GameMode.apply(this)
                    showOverlay()
                }
            } else {
                if (fg == g) off = 0 else off++
                if (off >= 4) { // ~8 s away from the game
                    game = null
                    GameMode.restore(this)
                    hideOverlay()
                    continue
                }
                refreshOverlay()
            }
        }
    }

    private fun showOverlay() = main.post {
        if (overlay != null || !Prefs.bool(this, "overlay", false) || !Settings.canDrawOverlays(this)) return@post
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11f
        tv.setBackgroundColor(0xAA000000.toInt())
        tv.setPadding(12, 4, 12, 4)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 20
        lp.y = 120
        var sx = 0
        var sy = 0
        var dx = 0f
        var dy = 0f
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY
            } else if (e.action == MotionEvent.ACTION_MOVE) {
                lp.x = sx + (e.rawX - dx).toInt()
                lp.y = sy + (e.rawY - dy).toInt()
                try { wm.updateViewLayout(tv, lp) } catch (x: Exception) {}
            }
            true
        }
        try {
            wm.addView(tv, lp)
            overlay = tv
            tv.text = getString(R.string.ov_fmt, SysInfo.mb(SysInfo.mem(this).avail))
        } catch (e: Exception) {
        }
    }

    private fun refreshOverlay() {
        main.post { overlay?.text = getString(R.string.ov_fmt, SysInfo.mb(SysInfo.mem(this).avail)) }
    }

    private fun removeOverlayNow() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {}
        }
        overlay = null
    }

    private fun hideOverlay() { main.post { removeOverlayNow() } }

    override fun onDestroy() {
        scope.cancel()
        GameMode.restore(this)
        removeOverlayNow()
        super.onDestroy()
    }
}
