package com.gameboost.lite

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

enum class Perm { USAGE, OVERLAY, DND, WRITE, A11Y }

class MainActivity : AppCompatActivity() {
    private val vm: MainViewModel by viewModels()
    private lateinit var ui: Ui
    private lateinit var box: FrameLayout
    private var scr = Scr.HOME
    private var memUi: ((Mem) -> Unit)? = null

    override fun attachBaseContext(b: Context) {
        val l = Prefs.str(b, "lang", "")
        if (l.isEmpty()) return super.attachBaseContext(b)
        val loc = Locale(l)
        Locale.setDefault(loc)
        val cfg = Configuration(b.resources.configuration)
        cfg.setLocale(loc)
        super.attachBaseContext(b.createConfigurationContext(cfg))
    }

    override fun onCreate(s: Bundle?) {
        val dark = Prefs.bool(this, "dark", true)
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(s)
        ui = Ui(this, dark)
        box = FrameLayout(this).apply { setBackgroundColor(ui.bg) }
        setContentView(box)
        show(Scr.HOME)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) { // nothing runs while the app is in the background
                launch { vm.mem.collect { memUi?.invoke(it) } }
                launch { vm.ver.collect { render() } }
                launch {
                    while (true) {
                        if (scr == Scr.HOME) vm.refresh()
                        delay(2000)
                    }
                }
            }
        }
    }

    override fun onBackPressed() {
        if (scr != Scr.HOME) show(Scr.HOME) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun s(id: Int) = getString(id)
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.put(v: View, top: Int = 8, w: Int = -1, weight: Float = 0f) = ui.put(this, v, top, w, weight)

    private fun open(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { toast(s(R.string.cant_open)) }
    }

    private fun appInfo(pkg: String) =
        open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

    private fun granted(p: Perm) = when (p) {
        Perm.USAGE -> Usage.has(this)
        Perm.OVERLAY -> Settings.canDrawOverlays(this)
        Perm.DND -> getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        Perm.WRITE -> Settings.System.canWrite(this)
        Perm.A11Y -> DeepCleanService.enabled()
    }

    /** Friendly explanation first, then the system settings page. Returns true if already granted. */
    private fun ask(p: Perm, skip: (() -> Unit)? = null): Boolean {
        if (granted(p)) return true
        val pk = Uri.parse("package:$packageName")
        val (t, w, i) = when (p) {
            Perm.USAGE -> Triple(R.string.p_usage_t, R.string.p_usage_w, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            Perm.OVERLAY -> Triple(R.string.p_overlay_t, R.string.p_overlay_w, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pk))
            Perm.DND -> Triple(R.string.p_dnd_t, R.string.p_dnd_w, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            Perm.WRITE -> Triple(R.string.p_write_t, R.string.p_write_w, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pk))
            Perm.A11Y -> Triple(R.string.p_a11y_t, R.string.p_a11y_w, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val b = AlertDialog.Builder(this).setTitle(t).setMessage(w)
            .setPositiveButton(R.string.open_settings) { _, _ -> open(i) }
            .setNegativeButton(R.string.cancel, null)
        if (skip != null) b.setNeutralButton(R.string.skip) { _, _ -> skip() }
        b.show()
        return false
    }

    private fun show(x: Scr) {
        scr = x
        vm.load(x)
        render()
    }

    private fun header(col: LinearLayout, title: String) {
        col.put(ui.btn("←  " + s(R.string.back), false) { show(Scr.HOME) }, 0)
        col.put(ui.text(title, 22f, bold = true), 12)
    }

    private fun render() {
        box.removeAllViews()
        memUi = null
        val col = ui.col().apply { setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(24)) }
        when (scr) {
            Scr.HOME -> home(col)
            Scr.GAMES -> games(col)
            Scr.PICK -> {
                header(col, s(R.string.edit_games))
                col.put(ui.text(s(R.string.pick_hint), 13f, ui.muted), 4)
                pick(col, Prefs.GAMES, false)
            }
            Scr.WHITE -> {
                header(col, s(R.string.m_white))
                col.put(ui.text(s(R.string.white_hint), 13f, ui.muted), 4)
                pick(col, Prefs.WHITE, true)
            }
            Scr.BG -> background(col)
            Scr.CACHE -> cache(col)
            Scr.START -> startup(col)
            Scr.DEEP -> deep(col)
            Scr.GUIDE -> guide(col)
            Scr.SETTINGS -> settings(col)
        }
        box.addView(ScrollView(this).apply { addView(col) })
    }

    // ---------- screens ----------
    private fun home(col: LinearLayout) {
        col.put(ui.text(s(R.string.app_name), 24f, bold = true), 0)
        val card = ui.card()
        val ram = ui.text("", 16f, bold = true)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ui.accent)
        }
        val sto = ui.text("", 13f, ui.muted)
        card.put(ram, 0)
        card.put(bar, 8)
        card.put(sto, 8)
        col.put(card, 12)
        val (t, f) = SysInfo.storage()
        sto.text = getString(R.string.storage_fmt, SysInfo.mb(t - f), SysInfo.mb(t))
        memUi = { m ->
            ram.text = getString(R.string.ram_fmt, SysInfo.mb(m.used), SysInfo.mb(m.total), SysInfo.mb(m.avail))
            bar.progress = (m.used * 100 / m.total).toInt()
        }
        memUi?.invoke(vm.mem.value)

        val busy = vm.busy.value
        val boost = ui.btn(s(if (busy) R.string.boosting else R.string.boost_now)) { vm.boost() }
        boost.textSize = 22f
        boost.minHeight = ui.dp(88)
        boost.minimumHeight = ui.dp(88)
        boost.isEnabled = !busy
        col.put(boost, 16)
        if (vm.msg.value.isNotEmpty()) col.put(ui.text(vm.msg.value, 15f, ui.accent), 8)

        val menu = listOf(
            R.string.m_games to Scr.GAMES, R.string.m_bg to Scr.BG, R.string.m_cache to Scr.CACHE,
            R.string.m_start to Scr.START, R.string.m_deep to Scr.DEEP, R.string.m_guide to Scr.GUIDE,
            R.string.m_white to Scr.WHITE, R.string.m_settings to Scr.SETTINGS
        )
        for ((r, sc) in menu) col.put(ui.btn(s(r), false) { show(sc) }, 8)
    }

    private fun games(col: LinearLayout) {
        header(col, s(R.string.m_games))
        col.put(ui.text(s(R.string.games_hint), 13f, ui.muted), 4)
        val sel = Prefs.set(this, Prefs.GAMES)
        val list = vm.apps.filter { it.pkg in sel }
        if (list.isEmpty()) col.put(ui.text(s(R.string.no_games)), 12)
        for (a in list) {
            val b = ui.btn("▶  " + a.label) { play(a.pkg) }
            b.minHeight = ui.dp(60)
            col.put(b, 8)
        }
        col.put(ui.btn(s(R.string.edit_games), false) { show(Scr.PICK) }, 16)
        if (vm.msg.value.isNotEmpty()) col.put(ui.text(vm.msg.value, 14f, ui.accent), 12)
    }

    private fun play(pkg: String) {
        if (!ask(Perm.USAGE)) return // needed to know when the game closes so settings can be restored
        val missing = listOfNotNull(
            Perm.DND.takeIf { Prefs.bool(this, "dnd", true) && !granted(Perm.DND) },
            Perm.WRITE.takeIf { Prefs.bool(this, "bright", false) && !granted(Perm.WRITE) },
            Perm.OVERLAY.takeIf { Prefs.bool(this, "overlay", false) && !granted(Perm.OVERLAY) }
        )
        if (missing.isNotEmpty()) {
            ask(missing[0]) { go(pkg) }
            return
        }
        go(pkg)
    }

    private fun go(pkg: String) = vm.play(pkg) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun pick(col: LinearLayout, key: String, showAuto: Boolean) {
        val sel = Prefs.set(this, key)
        val auto = if (showAuto) Apps.protectedPkgs(this) - sel else emptySet()
        for (a in vm.apps) {
            val isAuto = a.pkg in auto
            val cb = CheckBox(this)
            cb.text = a.label + if (isAuto) "  " + s(R.string.auto_note) else ""
            cb.textSize = 16f
            cb.setTextColor(ui.fg)
            cb.isChecked = isAuto || a.pkg in sel
            cb.isEnabled = !isAuto
            cb.setPadding(0, ui.dp(8), 0, ui.dp(8))
            cb.setOnCheckedChangeListener { _, _ -> Prefs.toggle(this, key, a.pkg) }
            col.put(cb, 0)
        }
    }

    private fun background(col: LinearLayout) {
        header(col, s(R.string.m_bg))
        col.put(ui.text(s(R.string.bg_hint), 13f, ui.muted), 4)
        val rec = vm.recent
        if (rec == null) {
            col.put(ui.btn(s(R.string.grant_usage)) { ask(Perm.USAGE) }, 12)
            return
        }
        if (rec.isEmpty()) col.put(ui.text(s(R.string.bg_none)), 12)
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for ((a, t) in rec) {
            val card = ui.card()
            card.put(ui.text(a.label, 16f, bold = true), 0)
            card.put(ui.text(getString(R.string.bg_row, (System.currentTimeMillis() - t) / 60000), 12f, ui.muted), 2)
            val r = ui.row()
            val stop = ui.btn(s(R.string.stop)) {
                try { am.killBackgroundProcesses(a.pkg); toast(getString(R.string.stopped, a.label)) }
                catch (e: SecurityException) { toast(s(R.string.cant_open)) }
            }
            val keep = ui.btn(s(if (a.pkg in Prefs.set(this, Prefs.WHITE)) R.string.kept else R.string.keep), false) {}
            keep.setOnClickListener {
                val on = Prefs.toggle(this, Prefs.WHITE, a.pkg)
                keep.text = s(if (on) R.string.kept else R.string.keep)
            }
            r.put(stop, 0, 0, 1f)
            r.put(keep, 0, 0, 1f)
            card.put(r, 8)
            col.put(card, 8)
        }
    }

    private fun cache(col: LinearLayout) {
        header(col, s(R.string.m_cache))
        col.put(ui.text(s(R.string.cache_hint), 13f, ui.muted), 4)
        col.put(ui.btn(s(R.string.clear_own)) {
            toast(getString(R.string.cleared, Formatter.formatShortFileSize(this, Apps.clearOwnCache(this))))
        }, 12)
        if (!Usage.has(this)) {
            col.put(ui.btn(s(R.string.grant_usage), false) { ask(Perm.USAGE) }, 8)
            return
        }
        for ((a, bytes) in vm.caches) {
            val card = ui.card()
            card.put(ui.text(a.label, 16f, bold = true), 0)
            card.put(ui.text(getString(R.string.cache_fmt, Formatter.formatShortFileSize(this, bytes)), 12f, ui.muted), 2)
            card.put(ui.btn(s(R.string.open_storage), false) { appInfo(a.pkg) }, 8)
            col.put(card, 8)
        }
    }

    private fun startup(col: LinearLayout) {
        header(col, s(R.string.m_start))
        col.put(ui.text(s(R.string.start_hint), 13f, ui.muted), 4)
        col.put(ui.btn(s(R.string.open_autostart)) {
            if (!AutoStart.openManager(this)) {
                toast(s(R.string.no_autostart))
                open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }, 12)
        col.put(ui.btn(s(R.string.open_battery), false) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, 8)
        for (a in vm.startup) {
            val card = ui.card()
            card.put(ui.text(a.label, 16f, bold = true), 0)
            card.put(ui.btn(s(R.string.app_info), false) { appInfo(a.pkg) }, 8)
            col.put(card, 8)
        }
    }

    private fun deep(col: LinearLayout) {
        header(col, s(R.string.m_deep))
        col.put(ui.text(s(R.string.deep_why), 14f), 8)
        if (!granted(Perm.A11Y)) col.put(ui.btn(s(R.string.enable_a11y)) { ask(Perm.A11Y) }, 12)
        else col.put(ui.btn(s(R.string.run_deep)) {
            val list = (Prefs.set(this, Prefs.DEEP) - Apps.protectedPkgs(this)).toList()
            if (list.isEmpty()) toast(s(R.string.deep_empty)) else DeepCleanService.run(list)
        }, 12)
        col.put(ui.text(s(R.string.pick_hint), 13f, ui.muted), 12)
        pick(col, Prefs.DEEP, false)
    }

    private fun guide(col: LinearLayout) {
        header(col, s(R.string.m_guide))
        col.put(ui.text(s(R.string.guide_body), 15f), 8)
        col.put(ui.btn(s(R.string.open_dev)) {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
            catch (e: Exception) {
                toast(s(R.string.dev_hidden))
                open(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))
            }
        }, 16)
        col.put(ui.btn(s(R.string.open_battery), false) {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, 8)
    }

    private fun check(col: LinearLayout, label: String, key: String, def: Boolean, onChange: ((Boolean) -> Unit)? = null) {
        val need = when (key) {
            "auto" -> Perm.USAGE
            "overlay" -> Perm.OVERLAY
            "dnd" -> Perm.DND
            "bright" -> Perm.WRITE
            else -> null
        }
        val cb = CheckBox(this)
        cb.text = label
        cb.textSize = 16f
        cb.setTextColor(ui.fg)
        cb.setPadding(0, ui.dp(8), 0, ui.dp(8))
        cb.isChecked = Prefs.bool(this, key, def) && (need == null || granted(need))
        cb.setOnCheckedChangeListener { v, on ->
            if (on && need != null && !granted(need)) {
                ask(need)
                (v as CheckBox).isChecked = false
            } else {
                Prefs.putBool(this, key, on)
                onChange?.invoke(on)
            }
        }
        col.put(cb, 4)
    }

    private fun settings(col: LinearLayout) {
        header(col, s(R.string.m_settings))
        check(col, s(R.string.set_auto), "auto", false) { if (it) GameService.start(this, null) }
        check(col, s(R.string.set_overlay), "overlay", false)
        check(col, s(R.string.set_dnd), "dnd", true)
        check(col, s(R.string.set_bright), "bright", false)
        val lbl = ui.text(getString(R.string.level_fmt, Prefs.int(this, "level", 50)), 13f, ui.muted)
        col.put(lbl, 0)
        val sb = SeekBar(this)
        sb.max = 90
        sb.progress = Prefs.int(this, "level", 50) - 10
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) {
                Prefs.putInt(this@MainActivity, "level", p + 10)
                lbl.text = getString(R.string.level_fmt, p + 10)
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        col.put(sb, 0)
        check(col, s(R.string.set_dark), "dark", true) {
            AppCompatDelegate.setDefaultNightMode(
                if (it) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
        col.put(ui.btn(s(R.string.set_lang), false) {
            val names = arrayOf("System default", "English", "Español", "Français", "Português")
            val codes = arrayOf("", "en", "es", "fr", "pt")
            AlertDialog.Builder(this).setItems(names) { _, i ->
                Prefs.putStr(this, "lang", codes[i])
                recreate()
            }.show()
        }, 12)
        col.put(ui.text(s(R.string.privacy), 12f, ui.muted), 16)
    }
}
