package com.gameboost.lite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Scr { HOME, GAMES, PICK, WHITE, BG, CACHE, START, DEEP, GUIDE, SETTINGS }

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val mem = MutableStateFlow(SysInfo.mem(app))
    val busy = MutableStateFlow(false)
    val msg = MutableStateFlow("")
    val ver = MutableStateFlow(0) // bumped whenever data for the current screen changes

    @Volatile var apps: List<AppItem> = emptyList()
    @Volatile var recent: List<Pair<AppItem, Long>>? = null
    @Volatile var caches: List<Pair<AppItem, Long>> = emptyList()
    @Volatile var startup: List<AppItem> = emptyList()

    private fun bump() = ver.update { it + 1 }

    fun refresh() { mem.value = SysInfo.mem(app) }

    /** Loads whatever the given screen needs, off the main thread. */
    fun load(s: Scr) {
        viewModelScope.launch(Dispatchers.Default) {
            when (s) {
                Scr.GAMES, Scr.PICK, Scr.WHITE, Scr.DEEP -> apps = Apps.launchable(app)
                Scr.BG -> recent = if (Usage.has(app)) Apps.recent(app) else null
                Scr.CACHE -> if (Usage.has(app)) {
                    caches = Apps.launchable(app).map { it to Apps.cacheSize(app, it.pkg) }
                        .filter { it.second > 0 }.sortedByDescending { it.second }.take(40)
                }
                Scr.START -> startup = AutoStart.list(app)
                else -> {}
            }
            bump()
        }
    }

    private fun describe(r: BoostResult): String {
        val freed = SysInfo.mb(r.after - r.before)
        return if (freed > 0) app.getString(R.string.boost_ok, freed, SysInfo.mb(r.before), SysInfo.mb(r.after))
        else app.getString(R.string.boost_none, SysInfo.mb(r.before), SysInfo.mb(r.after))
    }

    fun boost() {
        if (busy.value) return
        busy.value = true
        bump()
        viewModelScope.launch {
            msg.value = describe(Booster.boost(app))
            busy.value = false
            refresh()
            bump()
        }
    }

    /** Boost, start Game Mode, then let the activity launch the game. */
    fun play(pkg: String, launch: () -> Unit) {
        if (busy.value) return
        busy.value = true
        bump()
        viewModelScope.launch {
            msg.value = describe(Booster.boost(app, setOf(pkg)))
            GameService.start(app, pkg)
            launch()
            busy.value = false
            refresh()
            bump()
        }
    }
}
