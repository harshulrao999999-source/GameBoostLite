package com.gameboost.lite

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny programmatic UI kit: no XML layouts, no extra libraries, nothing animated. */
class Ui(val c: Context, dark: Boolean) {
    val bg = (if (dark) 0xFF101114 else 0xFFF2F2F2).toInt()
    val fg = (if (dark) 0xFFEDEDED else 0xFF111111).toInt()
    val muted = (if (dark) 0xFF9AA0A6 else 0xFF555555).toInt()
    val cardBg = (if (dark) 0xFF1E2025 else 0xFFFFFFFF).toInt()
    val accent = 0xFF00C853.toInt()

    fun dp(v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun shape(color: Int, r: Int = 12) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    fun text(s: CharSequence, sp: Float = 15f, color: Int = fg, bold: Boolean = false) = TextView(c).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun btn(s: String, primary: Boolean = true, click: () -> Unit) = Button(c).apply {
        text = s
        isAllCaps = false
        textSize = 16f
        setTextColor(if (primary) Color.BLACK else fg)
        background = shape(if (primary) accent else cardBg)
        minHeight = dp(52)
        minimumHeight = dp(52)
        setOnClickListener { click() }
    }

    fun col() = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

    fun row() = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun card() = col().apply {
        background = shape(cardBg)
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }

    fun put(p: LinearLayout, v: View, top: Int, w: Int, weight: Float) {
        val lp = LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
        if (p.orientation == LinearLayout.VERTICAL) lp.topMargin = dp(top)
        else if (p.childCount > 0) lp.marginStart = dp(8)
        p.addView(v, lp)
    }
}
